/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Articulo;
import dto.Capsula;
import dto.Categoria;
import dto.Cesta;
import dto.Direccion;
import dto.LineaPedido;
import dto.PedidoFactura;
import dto.Ticket;
import dto.TipoEstadoFacturacion;
import dto.TipoUsuario;
import dto.Usuario;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */
public class Test {
    public static void main(String[] args) throws SQLException  {
        
      
      CestaDAO cesta = new CestaDAO();
      ArticuloDao a = new ArticuloDao();
      
      
}
}